/*
 * host2ip.h - return IP address given a host name
 *
 * Copyright 1998-2001 by Columbia University; all rights reserved 
*/

extern struct in_addr host2ip(char *host);
